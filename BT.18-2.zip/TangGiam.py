n= int(input('Nhap So Luong Phan Tu:'))
a = []
for i in range(n):
    a.append(float(input('Phan Tu Thu %d: '%(i+1))))

print('Tang Dan:')
for i in range(0,n):
    for j in range(i,n):
        if(a[j]<a[i]):
            m = a[j]
            a[j]=a[i]
            a[i]=m
print(a)

print('Giam Dan:')
for i in range(0,n):
    for j in range(i,n):
        if(a[j]>a[i]):
            m = a[j]
            a[j]=a[i]
            a[i]=m
print(a)