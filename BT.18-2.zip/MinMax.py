n= int(input('Nhap So Luong Phan Tu:'))
a = []
for i in range(n):
    a.append(float(input('Phan Tu Thu %d: '%(i+1))))
print(a)
min=float(a[0])
max = float(a[0])
for i in range(n):
    if a[i] <min:
        min=a[i]
    if a[i]>max:
        max = a[i]
print('Min: ' + str(min) + ' | Max: ' + str(max))